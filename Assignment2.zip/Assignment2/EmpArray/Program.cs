﻿using System;
public class EmpArray {

    int eid;
    string name;
    double salary;
    public EmpArray() {
        eid = 0;
        name = "xyz";
        salary = 1000;
    }

    public void accept() {
        Console.WriteLine("enter Employee Id :");
        eid = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter Employee name :");
        name=Console.ReadLine();
        Console.WriteLine("enter Employee salary :");
        salary = Convert.ToDouble(Console.ReadLine());
    }

    public void display() {
        Console.WriteLine("Employee Data");
        Console.Write(eid+" "+name+" "+salary);
        Console.WriteLine();
    }
    
    
    public static void Main(String[] args) {
        Console.WriteLine("Enter how many employee you want");
        int n = Convert.ToInt32(Console.ReadLine());
        int i;
        EmpArray[] ob = new EmpArray[n];
        for (i = 0; i <n; i++) {
            ob[i] = new EmpArray();
            ob[i].accept();
            ob[i].display();
        }
        Console.ReadLine();
    }
}