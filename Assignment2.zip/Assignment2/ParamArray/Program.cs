﻿using System;

public class ParamArray {

    public int AvgArray(params int[] arr) {
        int sum=0, avg=0;
        int n = arr.Length;

        for(int i = 0; i < n; i++)
        {
            sum = sum + arr[i];

        }

        avg = sum / n;
        return avg;
    }


    public static void Main(string[] args) { 
       
        ParamArray p=new ParamArray();
        Console.WriteLine("Avg Salary of Employee is : " + p.AvgArray(10,20,30,40 ) );
        Console.WriteLine("Avg Salary of Employee is : " + p.AvgArray(5, 8, 15, 20));

    }
}

