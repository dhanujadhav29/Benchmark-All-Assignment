﻿using System;

public class DaysEnum {
    enum Days { Sun, Mon, Tue, Wed, Thu,Fri,Sat};


     public static void Main(string[] args) {
        int WeekStart = (int)Days.Mon;
        int WeekEnd = (int)Days.Sun;

        Console.WriteLine("Monday: {0}",WeekStart);
        Console.WriteLine("Sunday: {0}", WeekEnd);

    }
}