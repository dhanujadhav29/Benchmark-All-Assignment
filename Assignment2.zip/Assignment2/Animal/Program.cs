﻿using System;
public abstract class Animal {

    public abstract void foodHabbits();
}

public class Herb : Animal
{
    public override void foodHabbits()
    {
        Console.WriteLine("Herbivorous : Only eat Veg");
    }

}

public class Carn : Animal {
    public override void foodHabbits()
    {
        Console.WriteLine("Carnivorous : Only eat  Non-Veg");
    }
}

public class Demo { 
   public static void Main(String[] args)
    {
        Animal ob;
        ob = new Carn();
        ob.foodHabbits();
        ob = new Herb();
        ob.foodHabbits();
    }
}