﻿using System;

public abstract class Shape {
    public abstract void area();
}

public class Circle : Shape {

    Double radius,a;

    public Circle(double r) {
        radius = r;
    }
    public override void area() {
        a = 3.14 * radius * radius;

        Console.WriteLine("Area of Circle is: " + a);

    }
}

public class Rectangle : Shape {

    double len, width,a;

    public Rectangle(double l,double w) {
        len = l;
        width = w;
    }
    public override void area()
    {

        a = len * width;
        Console.WriteLine("Area of Rectangle is: " + a);

    }
}

public class Demo {
    public static void Main(string[] args) {

        Shape s;

        s = new Circle(3.2);
        s.area();

        s = new Rectangle(1.2,2.1);
        s.area();
    }
}