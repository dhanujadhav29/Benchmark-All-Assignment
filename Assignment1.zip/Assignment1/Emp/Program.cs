﻿using System;
public class Employee
{
    int eid;
    string name, designation;
    Double salary;

    public void accept()
    {
        Console.WriteLine("enter employee id :");
        eid = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter employee name :");
        name = Console.ReadLine();
        Console.WriteLine("enter employee designation :");
        designation = Console.ReadLine();
        Console.WriteLine("enter employee salary :");
        salary = Convert.ToDouble(Console.ReadLine());

    }


    public void display()
    {
        Console.WriteLine("Employee Data");
        Console.Write(eid + " " + name + " " + designation + " " + salary);
        Console.WriteLine();
    }


    public static void Main(String[] args)
    {
        int n, i;
        Console.WriteLine("Enter how many employee you want to print");
        n = Convert.ToInt32(Console.ReadLine());
        Employee ob = new Employee();
        for (i = 1; i <= n; i++) {
            
            ob.accept();
            ob.display();
        }
        
        Console.ReadLine();
    }
}