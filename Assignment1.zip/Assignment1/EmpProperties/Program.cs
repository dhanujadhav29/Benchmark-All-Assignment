﻿using System;
public class EmpProperties
{
    int eid;
    string name, designation;
    Double salary;

    public int Eid
    {
        get {
            return eid;
        }
        set { 
        eid= value;
        }
    
    }

    public string Name
    {
        get
        {
            return name;
        }
        set
        {
            name = value;
        }

    }

    public string Des
    {
        get
        {
            return designation;
        }
        set
        {
            designation = value;
        }

    }

    public double Sal
    {
        get
        {
            return salary;
        }
        set
        {
            salary = value;
        }

    }

    public override string ToString()
    {
        return Eid + " "+Name+" "+Des+" "+Sal;
    }

    public static void Main(String[] args)
    {
        EmpProperties ob = new EmpProperties();
        ob.Eid = 1;
        ob.Name = "xyz";
        ob.Des = "HR";
        ob.Sal = 35000;

        Console.WriteLine(ob);
        Console.ReadLine();
    }
}