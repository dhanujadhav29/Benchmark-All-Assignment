﻿using System;
public class Calculator {

    int num;
    public Calculator() {
        num = 0;
    }

    public Calculator(int n) {
        num = n;
    }

    public static Calculator operator + (Calculator ob1,Calculator ob2) {
        Calculator ob3 = new Calculator();
        ob3.num = ob1.num + ob2.num;
        return ob3;
    }

    public void display() {
        Console.WriteLine(num);
    }


    public static void Main(String[] args) { 
       Calculator ob1 = new Calculator(20);
       Calculator ob2 = new Calculator(10);
       Calculator ob = new Calculator(10);

        ob = ob1 + ob2;
        ob1.display();
        ob2.display();
        ob.display();
    
    }

}