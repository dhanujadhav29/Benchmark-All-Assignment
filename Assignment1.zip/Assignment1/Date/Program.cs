﻿using System;
public class Date {
    public static void Main(String[] args) {
        char ch;
        int day, m, year;
        do {
            Console.WriteLine("case 1: Day  case 2: Month case 3 : Year case4 : Date");
            Console.WriteLine("Enter your choice");
             ch = Convert.ToChar(Console.ReadLine());

            switch (ch) {

                case '1':
                          Console.WriteLine("Enter a day");
                          day = Convert.ToInt32(Console.ReadLine());
                            if (day <= 31) {
                             Console.WriteLine("Day is :"+day);
                            }
                          break;
                case '2':
                          Console.WriteLine("Enter a month");
                          m = Convert.ToInt32(Console.ReadLine());
                            if (m <= 12)
                            {
                                Console.WriteLine("Month is :" + m);
                            }
                           break;
                case '3':
                          Console.WriteLine("Enter a year");
                          year = Convert.ToInt32(Console.ReadLine());
                            if (year >= 1999)
                            {
                                Console.WriteLine("Year is :" + year);
                            }
                           break;


                case '4':
                            Console.WriteLine("Enter a day, month and year");
                            day = Convert.ToInt32(Console.ReadLine());
                            m = Convert.ToInt32(Console.ReadLine());
                            year = Convert.ToInt32(Console.ReadLine());
                                if (day<=31 && m<=12 && year>=1999)
                                {
                                    Console.WriteLine("Date is :" +day +":"+m+":"+ year);
                                }
                           break;
            }
            
        } while (ch=='5' || ch=='5');

        Console.ReadLine();
    }
}