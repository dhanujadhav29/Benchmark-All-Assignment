﻿using System;
public class MonthCheck
{
    public static void Main(String[] args)
    {
        char ch;
        
        do
        {
            Console.WriteLine("Enter your choice");
            ch = Convert.ToChar(Console.ReadLine());

            switch (ch)
            {

                case '1':
                            Console.WriteLine("31 Days ");
                            break;
                case '2':
                            Console.WriteLine("30 Days ");
                            break;
                case '3':
                            Console.WriteLine("29 Days Leap Year!");
                            break;
                case '4':
                            Console.WriteLine("28 Days ");
                            break;

            }

        } while (ch == '5' || ch == '5');

        Console.ReadLine();
    }
}