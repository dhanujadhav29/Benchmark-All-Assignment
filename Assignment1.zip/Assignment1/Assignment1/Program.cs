﻿using System;
public class Fibonacci {
    public static void Main(string[] args) {
        int n, a=0, b=1, i;
        Console.WriteLine("Enter how many numbers you want to print");
        n = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Fibonacci Series");
        Console.Write(a+" "+b);
        for (i = 2; i <= n; i++) {
            int c = a + b;
            Console.Write(" "+c);
            a = b;
            b = c;
        }
       

        Console.ReadLine();
    }

}