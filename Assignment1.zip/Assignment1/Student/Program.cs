﻿using System;
public class Student {

    int roll;
    String name;
    string addr;

    Student() {
        roll = 1;
        name = "Dhanu";
        addr = "Pune";
    }

    Student(int roll,string name,string addr)
    {
        this.roll = roll;
        this.name = name;
        this.addr = addr;
    }
   

    public void display() {
        Console.WriteLine(roll+" "+name+" "+addr);
    
    }

    public static void Main(String[] args) {
      
        //no-arg constructor
        Student st = new Student();
        st.display();

        //parameterized constructor
        Student st1 = new Student(1,"abc","mumbai");
        st1.display();
    }
    
}