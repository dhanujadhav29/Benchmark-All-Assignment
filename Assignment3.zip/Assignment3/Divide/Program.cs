﻿using System;

public class Divide {

    public void calculate(int a,int b) {
        try {
            int c = a / b;
            Console.WriteLine("Division is :"+c);
        }
        catch (DivideByZeroException e) {
            Console.WriteLine("Number can not divided by zero" + e);
        }
        catch (IndexOutOfRangeException e) {
            Console.WriteLine("Index out of range" + e);
        }
        catch (Exception e) {
            Console.WriteLine("Invalid Error" + e);
        }
    }

    public static void Main(string[] args) {
        int a, b;
        Console.WriteLine("Enter 1st number");
        a=Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter 2nd number");
        b=Convert.ToInt32(Console.ReadLine());


        Divide ob = new Divide();
        ob.calculate(a,b);

    }
   
}