﻿using System;

public interface Printable {
  
    public abstract void printData(string name);
}

public class Account : Printable
{
    public override void printData(string name)
    {
        Console.WriteLine("Account holder name is:" + name);
    }

}

public class Emp : Printable {
    public override void printData(string name)
    {
        Console.WriteLine("Employee name is:" + name);
    }
}

public class Test {
    public static void Main(string[] args) {
        Printable p;
        p = new Account();
        p.printData("Dhanu");
        p = new Emp();
        p.printData("Xyz");
        Console.ReadLine();
    }
}