﻿using System;

public class Temp
{

    public void calculate(int a, int b)
    {
        try
        {
            int c = a / b;
            Console.WriteLine("Division is :" + c);

            throw new DivideByZeroException("Number can not divided by zero");

        }
        catch (IndexOutOfRangeException e)
        {
            Console.WriteLine("Index out of range" + e);
        }
        catch (Exception e)
        {
            Console.WriteLine("Invalid Error" + e);
        }
    }

    public static void Main(string[] args)
    {
        int a, b;
        Console.WriteLine("Enter 1st number");
        a = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter 2nd number");
        b = Convert.ToInt32(Console.ReadLine());


        Temp ob = new Temp();
        ob.calculate(a, b);

    }

}