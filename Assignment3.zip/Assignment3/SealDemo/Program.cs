﻿using System;

sealed public class Teacher {

    public void teach() {
        Console.WriteLine("Teacher role is Teaching");
    }
}


public class Student : Teacher {

    //teacher can not be overridden becaus it is sealed
    public void learn() {
        Console.WriteLine("Student role is to learn");
    }
}


public class Demo { 
public static void Main(string[] args) {
        Student s = new Student();
        s.learn();
        //s.teach();
        //using this example we can clarify that sealed method can not be inherited
}
}