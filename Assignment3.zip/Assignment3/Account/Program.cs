﻿using System;

public abstract class Account {

   public int rate, days,time;
   public double pamt;

    public Account() { 
    
    }
   
    public abstract void CalInterest();

}


public class Saving : Account {


    public Saving(double pamt,int rate,int days) { 
    
        this.pamt = pamt;
        this.rate = rate;
        this.days = days;
    }
    public override void CalInterest() {
        double interest;
        interest = (pamt * rate * days) / (365);
        Console.WriteLine("Interest for Saving account is :"+interest);
    }

}

public class Current : Account
{

    public Current(double pamt,int rate,int time) { 
      this.pamt= pamt;
      this.rate = rate;
      this.time = time;
    }
    public override void CalInterest()
    {
        double interest;
        interest = (pamt * rate * time);
        Console.WriteLine("Interest for Current account is :" + interest);

    }
}


public class Fd : Account
{

    public Fd(double pamt,int rate) {

        this.pamt = pamt;
        this.rate= rate;
    }
    public override void CalInterest()
    {
        double interest;
        interest = (pamt * rate);
        Console.WriteLine("Interest for Saving account is :" + interest);
     }
}

public class Test {
    public static void Main(string[] args) {

        char ch;
        Console.WriteLine("case 1 : Saving  case 2 : Current  case 3 : Fixed");
        Console.WriteLine("Enter your choice");
        ch = Convert.ToChar(Console.ReadLine());

        Account ob;

        if (ch == '1')
        {
            ob = new Saving(10000,6,7);
            Console.ReadLine();
            ob.CalInterest();
        }
        else if (ch == '2')
        {
            ob = new Current(12000,4,5);
            ob.CalInterest();

        }
        else if (ch == '3')
        {
            ob = new Fd(20000,8);
            ob.CalInterest();
        }
        else {
            Console.WriteLine("Invalid choice");
        }

        Console.ReadLine();
    
    }
}