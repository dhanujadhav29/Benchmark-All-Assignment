﻿using System;

    public class Program
    {
        public static void Main(string[] args)
        {
            int[] arr = { 6,8,3,9,4 };
            int i;
            for (i = 0; i <arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
            try
            {
            Console.WriteLine(arr[6]);
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine("Check valid array index"+e);
            }

        Console.ReadLine();
        }
   }