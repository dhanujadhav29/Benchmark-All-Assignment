﻿using System;

public class Demo {

    public static void Swap<T>(ref T x ,ref T y ) {
        T temp;
        temp = x;
        x = y;
        y= temp;
    
    }
    public static void Main(String[] args) {
        int a = 10,b=15;
        float c = 13.5f, d= 16.8f;
        char p ='M',q='N';

        Console.WriteLine("For integer value");
        Console.WriteLine("Before Swapping : "+a+" "+b);
        Swap<int>(ref a,ref b);
        Console.WriteLine("After Swapping : "+a+" "+b);

        Console.WriteLine();
        Console.WriteLine("For float value");
        Console.WriteLine("Before Swapping : "+c+" "+d);
        Swap<float>(ref c, ref d);
        Console.WriteLine("After Swapping : "+c+" "+d);

        Console.WriteLine();
        Console.WriteLine("For character value");
        Console.WriteLine("Before Swapping : "+p+" "+q);
        Swap<char>(ref p, ref q);
        Console.WriteLine("After Swapping : "+p+" "+q);





    }
}