﻿using System;
public class GenEmployee {
    public static void Main(String[] args) { 
       Dictionary<int,String> employee=new Dictionary<int,String>();
        employee.Add(1,"Dhanashree");
        employee.Add(2, "Akash");
        employee.Add(3, "Sujate");
        employee.Add(4, "Kunal");
        employee.Add(5, "Atharva");

        Console.Write("List of Employees");
        Console.WriteLine();
        foreach (KeyValuePair<int, string> kv in employee) {
           
            Console.WriteLine(kv.Key+" "+kv.Value);
        }
        Console.ReadLine();
    }
}