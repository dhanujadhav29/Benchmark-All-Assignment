﻿using System;

public class FileDemo {
    public static void Main(string[] args) { 
      DirectoryInfo dir = new DirectoryInfo("D:\\All c# code\\Assignment1");

        if (dir.Exists)
        {
             Console.WriteLine(dir.FullName);
             Console.WriteLine(dir.CreationTime);
             Console.WriteLine(dir.LastAccessTime);
             Console.WriteLine(dir.LastWriteTime);
             Console.WriteLine(dir.Name);
             Console.Write(dir.Parent);
             FileInfo[] f=dir.GetFiles();
            foreach (FileInfo fd in f) { 
               Console.WriteLine(fd.Name);
               Console.WriteLine(fd.Extension);
               Console.WriteLine(fd.CreationTime);
                Console.WriteLine(fd.LastWriteTime);
            }
        }
        else {
            dir.Create();
            Console.WriteLine("Directory created");
        }

        Console.ReadLine();
    }

}