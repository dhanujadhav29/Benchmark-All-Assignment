﻿using System;
using System.Collections;
public class Student
{
    public static void Main(String[] args)
    {
        SortedDictionary<int, String> stud = new SortedDictionary<int, string>();
        stud.Add(5, "Dhanashree");
        stud.Add(2, "Akash");
        stud.Add(4, "Sujate");
        stud.Add(1, "Kunal");
        stud.Add(3, "Atharva");

        Console.Write("List of Student Using SortedDictionary");
        Console.WriteLine();
        foreach (KeyValuePair<int, string> kv in stud)
        {

            Console.WriteLine(kv.Key + " " + kv.Value);
        }
        


        Hashtable s = new Hashtable();
        s.Add(1,"tejas");
        s.Add(2,"ojas");
        s.Add(3,"pankaj");
        s.Add(4, "gaurav");
        s.Add(5, "prem");

        Console.WriteLine();
        Console.Write("List of Student Using Hashtable");
        Console.WriteLine();
        foreach (DictionaryEntry d in s) {
            Console.WriteLine(d.Key+" "+d.Value);
        }
        Console.ReadLine();
    }
}