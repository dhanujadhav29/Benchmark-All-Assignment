﻿using System;

public class Test {

    string s;
    int id;
    public Test(String s,int id) {
        this.s = s;
        this.id = id;
    }
    public static void Main(string[] args) {


        DateTime d=DateTime.Now;
        Console.WriteLine(d.ToString());

        Test t1 = new Test("Dhanu",1);
        Test t2 = new Test("Dhanu",1);

        bool b=t1.Equals(t2);
        if (b == true)
        {
            Console.WriteLine("Both objects are equal");
        }
        else {
            Console.WriteLine("Both objects are not equal");
        }

        Console.ReadLine();

    }

}