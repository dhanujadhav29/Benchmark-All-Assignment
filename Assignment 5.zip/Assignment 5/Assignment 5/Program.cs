﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

public class Employee {

    SqlConnection con=null ;
    SqlCommand cmd = null;
    SqlDataReader reader = null;
    //1 get all emp
    public SqlDataReader GetEmpData() {
        
        try
        {
            con = new SqlConnection();

            con.ConnectionString = "Server=.;Database=Assign1;trusted_connection=true";
            con.Open();
            
            cmd = new SqlCommand("GetEmpData", con);
            cmd.CommandType = CommandType.StoredProcedure;
            reader = cmd.ExecuteReader();
        }
        catch (Exception e)
        {
            Console.WriteLine("Error" + e);
        }
       

        return reader;

    }



    // 2 Emp data using eno

    public SqlDataReader GetEmpDataUsingEno(int eno)
    {
        
        try
        {
            con = new SqlConnection();

            con.ConnectionString = "Server=.;Database=Assign1;trusted_connection=true";
            con.Open();

            cmd = new SqlCommand("GetEmpDataUsingEno", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter param1 = new SqlParameter("eno",eno);
            cmd.Parameters.Add(param1);
            reader = cmd.ExecuteReader();   
        }
        catch (Exception e)
        {
            Console.WriteLine("Error" + e);
        }
        

        return reader;
      }



    //3 insert
    public int InsertEmployee(int eno, string ename, int salary, int dno) {
        
        int res = 0;
        try
        {
            con = new SqlConnection();

            con.ConnectionString = "Server=.;Database=Assign1;trusted_connection=true";
            con.Open();

            cmd = new SqlCommand("InsertEmp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter param1 = new SqlParameter("eno", eno);
            SqlParameter param2 = new SqlParameter("ename", ename);
            SqlParameter param3 = new SqlParameter("salary", salary);
            SqlParameter param4 = new SqlParameter("dno", dno);
            cmd.Parameters.Add(param1);
            cmd.Parameters.Add(param2);
            cmd.Parameters.Add(param3);
            cmd.Parameters.Add(param4);
            res = cmd.ExecuteNonQuery();
        }
        catch (Exception e) {
           Console.WriteLine("Error" + e);
        }
        
        return res;

    }


    //4 update
    public int UpdateEmployee(int eno,string ename, int salary, int dno)
    {
        
        int res = 0;
        try
        {
            con = new SqlConnection();

            con.ConnectionString = "Server=.;Database=Assign1;trusted_connection=true";
            con.Open();

            cmd = new SqlCommand("UpdateEmpData", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter param1 = new SqlParameter("eno", eno);
            SqlParameter param2 = new SqlParameter("ename", ename);
            SqlParameter param3 = new SqlParameter("salary", salary);
            SqlParameter param4 = new SqlParameter("dno", dno);
            cmd.Parameters.Add(param1);
            cmd.Parameters.Add(param2);
            cmd.Parameters.Add(param3);
            cmd.Parameters.Add(param4);
            res = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine("Error" + e);
        }
       
        return res;

    }


    //5 Delete
    public int DeleteEmployee(int eno)
    {
        
        int res = 0;
        try
        {
            con = new SqlConnection();

            con.ConnectionString = "Server=.;Database=Assign1;trusted_connection=true";
            con.Open();

            cmd = new SqlCommand("DeleteEmpUsingEno", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter param1 = new SqlParameter("eno", eno);
            cmd.Parameters.Add(param1);
            res = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine("Error" + e);
        }
 
        return res;

    }
    
    public void printReader(SqlDataReader reader) {
        while (reader.Read())
        {
            Console.WriteLine(reader[0].ToString() + "\t" + reader[1].ToString() + "\t" + reader[2].ToString() + "\t" + reader[3].ToString() + "\t");
        }
        Console.ReadLine();
    }

}

public class Test {
    public static void Main(string[] args)
    {

        /*
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader reader=null;
        try {
            con = new SqlConnection();

            //con.ConnectionString = "Server=OSEMMI9\\SQLEXPRESS01; Initial Catalog = Assign1; Integrated Security = True";
            con.ConnectionString = "Server=.;Database=Assign1;trusted_connection=true";
            con.Open();
            // Query for select
            //cmd = new SqlCommand("Select * From Emp", con);

            //Query for Update
            cmd = new SqlCommand("Update Emp Set ", con);
            cmd.CommandType = CommandType.Text;
            reader = cmd.ExecuteReader();
            while (reader.Read()) {
                Console.WriteLine(reader[0].ToString()+"\t"+reader[1].ToString()+"\t"+ reader[2].ToString() + "\t" + reader[3].ToString() + "\t");
            }
            Console.ReadLine();
        }
        catch (Exception e) {
            Console.WriteLine("Error"+e);        
        }
        finally{
            con.Close();
        
        }
   */



        //switch case according to user choice
        Employee ob = new Employee();
        int ch;
       
        do {
            Console.WriteLine("Menu");
            Console.WriteLine("Case 1 : Get Employee Data");
            Console.WriteLine("Case 2 : Get Employee Data Using Eno");
            Console.WriteLine("Case 3 : Insert Employee Data");
            Console.WriteLine("Case 4 : Update Employee Data");
            Console.WriteLine("Case 5 : Delete Employee Data");


            Console.WriteLine("enter your choice");
            ch = Convert.ToInt32(Console.ReadLine());

            switch (ch) {
                case 1:ob.printReader(ob.GetEmpData());
                       break;

                case 2: Console.WriteLine("Enter Employee number :");
                        int enno=Convert.ToInt32(Console.ReadLine());
                        
                        ob.printReader(ob.GetEmpDataUsingEno(enno));
                        break;


                case 3:
                        Console.WriteLine("Enter Employee number :");
                        int eno = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Employee Name :");
                        string ename = Console.ReadLine();
                        Console.WriteLine("Enter Employee salary :");
                        int sal = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Dept number :");
                        int dno = Convert.ToInt32(Console.ReadLine());
                        ob.InsertEmployee(eno,ename,sal,dno);

                        Console.WriteLine("Data inserted !");
                        break;

                case 4:
                        Console.WriteLine("Enter Employee number :");
                        int eno1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Employee Name :");
                        string ename1 = Console.ReadLine();
                        Console.WriteLine("Enter Employee salary :");
                        int sal1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Dept number :");
                        int dno1 = Convert.ToInt32(Console.ReadLine());
                        ob.UpdateEmployee(eno1,ename1, sal1, dno1);

                        Console.WriteLine("Data Updated !");
                        break;
                case 5:
                        Console.WriteLine("Enter Employee number to be delete :");
                        int no1 = Convert.ToInt32(Console.ReadLine());
                        ob.DeleteEmployee(no1);
                        Console.WriteLine("Employee deleted !");
                        break;

               default: Console.WriteLine("Invalid choice");
                        break;
            }
        } while (ch!=5);

        Console.ReadLine();
    }
  
}